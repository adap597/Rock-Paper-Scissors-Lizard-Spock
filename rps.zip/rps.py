import random
import colorama
from colorama import Fore, Back, Style
colorama.init()


"""This program plays a game of Rock, Paper, Scissors, Lizard, Spock
between two Players, and reports both Player's scores each round."""

"""The Player class is the parent class for all of the Players
in this game"""


class Player:
    moves = ['rock', 'paper', 'scissors', 'lizard', 'spock']

    def __init__(self):
        # initialization of the list for the move function
        self.my_move = self.moves
        # random choice for first round
        self.their_move = 'rock'

    def learn(self, my_move, their_move):
        # stores moves of the players
        self.my_move = my_move
        self.their_move = their_move


class RandomPlayer(Player):
    def move(self):
        # random move
        return random.choice(self.moves)


class ReflectPlayer(Player):
    def move(self):
        # reflects the choice of the previous round
        return self.their_move


class CyclePlayer(Player):
    def move(self):
        # cycles through the list of options
        if self.my_move == self.moves[0]:
            return self.moves[1]
        elif self.my_move == self.moves[1]:
            return self.moves[2]
        elif self.my_move == self.moves[2]:
            return self.moves[3]
        elif self.my_move == self.moves[3]:
            return self.moves[4]
        else:
            return self.moves[0]


class HumanPlayer(Player):
    def move(self):
        # repeats the input statement until there is
        # a match with the list or quit
        while True:
            move_human = input(Fore.LIGHTGREEN_EX +
                               "Rock, paper, scissors, lizard, Spock? > "
                               + Style.RESET_ALL)
            if move_human.lower() in self.moves:
                return move_human.lower()
            elif move_human.lower() == 'quit':
                exit()


class Game:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        # scores initialization
        self.score_p1 = 0
        self.score_p2 = 0

    def beats(self, one, two):
        # rock beats scissors, scissors beat paper
        # paper beats rock, lizard beats paper and spock
        # spock beats rock and scissors
        return ((one == 'rock' and two == 'scissors') or
                (one == 'scissors' and two == 'paper') or
                (one == 'paper' and two == 'rock') or
                (one == 'lizard' and two == 'paper') or
                (one == 'lizard' and two == 'spock') or
                (one == 'spock' and two == 'rock') or
                (one == 'spock' and two == 'scissors'))

    def rounds(self):
        # repeats the input statement until there is
        # a valid choice or quit
        while True:
            self.number_rounds = input(Fore.CYAN + "Enter number of rounds: > "
                                       + Style.RESET_ALL)
            if self.number_rounds.isdigit():
                return self.number_rounds
            elif self.number_rounds.lower() == 'quit':
                exit()

    def play_round(self):
        # move
        move1 = self.p1.move()
        move2 = self.p2.move()
        # result of the match and stores players scores
        if self.beats(move1, move2):
            self.score_p1 += 1
            winner = '**** PLAYER ONE WINS ****'
        elif move1 == move2:
            self.score_p1 = self.score_p1
            self.score_p2 = self.score_p2
            winner = '**** TIE ****'
        else:
            self.score_p2 += 1
            winner = '**** PLAYER TWO WINS ****'
        # output the match results
        print(Fore.LIGHTYELLOW_EX +
              f"> You played : {move1}" + Style.RESET_ALL + Fore.BLUE +
              f"\n> Opponent played : {move2}" + Style.RESET_ALL +
              Fore.LIGHTRED_EX +
              f"\n{winner}" + Style.RESET_ALL +
              f"\nScore: Player one ( {self.score_p1} ) "
              f"Player two ( {self.score_p2} )"
              )
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)

    def play_game(self):
        print(Fore.YELLOW +
              # start of the game message and instructions
              ">>>> Game start! <<<<" + Style.RESET_ALL +
              "\n(To quit the game, enter \'quit\'."
              " First, enter the number of rounds you want to play."
              " Then, enter your move for each round.)"
              )
        self.rounds()
        # for loop for the user selected number of rounds
        for round in range(int(self.number_rounds)):
            # prints round number with yellow background and black text
            print(Fore.BLACK + Back.LIGHTYELLOW_EX + f"\nRound {round + 1} --"
                  + Style.RESET_ALL)
            self.play_round()
        # if statement block displays results of the game and the final scores
        if self.score_p1 == self.score_p2:
            print(Fore.BLACK + Back.LIGHTRED_EX +
                  f"\n---- The game ended in a tie! ----" + Style.RESET_ALL +
                  f"\nScore: Player one ( {self.score_p1} ) "
                  f"Player two ( {self.score_p2} )"
                  )
        elif self.score_p1 > self.score_p2:
            print(Fore.BLACK + Back.LIGHTRED_EX +
                  f"\n---- Player ONE has won! ----" + Style.RESET_ALL +
                  f"\nScore: Player one ( {self.score_p1} )"
                  + Fore.LIGHTRED_EX +
                  "* " + Style.RESET_ALL +
                  f"Player two ( {self.score_p2} )"
                  )
        else:
            print(Fore.BLACK + Back.LIGHTRED_EX +
                  f"\n---- Player TWO has won! ----" + Style.RESET_ALL +
                  f"\nScore: Player one ( {self.score_p1} ) "
                  f"Player two ( {self.score_p2} )" + Fore.LIGHTRED_EX +
                  "*" + Style.RESET_ALL
                  )


if __name__ == '__main__':
    # organize the game with a human player and
    # randomly chooses opponent from the other player classes
    game = Game(HumanPlayer(), random.choice(
        [RandomPlayer(), ReflectPlayer(), CyclePlayer()]))
    game.play_game()
